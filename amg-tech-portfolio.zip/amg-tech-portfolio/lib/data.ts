export const brand = "amg-tech";

export const dev = {
  name: "Muhammed Adamu Girei",
  role: "Web Developer",
  location: "Nigeria",
  skills: ["JavaScript", "React", "Next.js", "API Integration", "Tailwind CSS"],
  status: "Available for work",
  passion: "Building beautiful user experiences",
};

export const about = {
  name: "Muhammed Adamu Girei",
  role: "Frontend Developer",
  focus: "Responsive Web Development",
  currentlyLearning: ["Node.js", "Next.js", "UI/UX"],
  goal: "Build modern applications people enjoy using.",
};

export const chips = ["React", "Next.js", "JavaScript", "Tailwind CSS", "TypeScript"];

export const aboutCards = [
  { title: "Web Development", color: "text-blue-400", from: "left" as const, text: "I build fast, responsive and modern websites using HTML, CSS, JavaScript, Tailwind CSS and React with attention to user experience and clean code." },
  { title: "Passion", color: "text-green-400", from: "right" as const, text: "I enjoy transforming ideas from Figma into beautiful, responsive interfaces that work perfectly on every device." },
  { title: "Mission", color: "text-yellow-400", from: "left" as const, text: "To create digital experiences that are clean, accessible, visually appealing and enjoyable to use." },
];

export const projects = [
  { file: "babz-lounge.tsx", title: "Babz Lounge", image: "", text: "A premium website for a restaurant and lounge in Jimeta, with a hero slider, menu page and WhatsApp ordering that captures the customer's delivery address.", tech: ["Next.js", "TypeScript", "Framer Motion"], demo: "#" },
  { file: "misa-ng.tsx", title: "MISA NG LTD", image: "", text: "A website for MISA NG LTD covering property listings, a real estate and finance newsfeed, developer onboarding and investment.", tech: ["Next.js", "TypeScript", "Tailwind"], demo: "#" },
  { file: "opay-demo.tsx", title: "OPay App Demo", image: "", text: "A demo clone of the OPay mobile banking app with home, transactions, transfer, cards, savings and rewards screens.", tech: ["Mobile UI", "Fintech", "Demo"], demo: "#" },
];

export const contact = {
  email: "amgtech100@gmail.com",
  location: "Nigeria",
  phone: "+2349168426276",
  phoneLabel: "+234 916 842 6276",
  github: "https://github.com/mohgirei10",
  instagram: "https://instagram.com/mohh_girei",
  whatsapp: "https://wa.me/2349168426276",
};
