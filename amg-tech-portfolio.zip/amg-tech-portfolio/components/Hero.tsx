import CodeWindow from "./CodeWindow";
import CodeObj from "./CodeObj";
import PhotoFrame from "./PhotoFrame";
import { dev } from "@/lib/data";

export default function Hero() {
  return (
    <section id="home" className="mx-auto max-w-5xl overflow-x-clip px-5 pb-8 pt-14 md:grid md:grid-cols-2 md:items-center md:gap-12">
      <div>
        <h1 className="sr-only">Muhammed Adamu Girei, Web Developer</h1>
        <p className="font-mono text-green-500">{"// Welcome to my portfolio"}</p>
        <CodeWindow file="developer.js" className="mt-6">
          <CodeObj name="developer" data={dev} />
        </CodeWindow>
        <div className="mt-8 flex gap-4">
          <a href="#projects" className="rounded-lg bg-blue-600 px-6 py-3 font-semibold text-white hover:bg-blue-500">View Projects</a>
          <a href="/assets/Resume.pdf" download className="rounded-lg border border-blue-900 px-6 py-3 text-white hover:bg-blue-950">Download CV</a>
        </div>
      </div>
      <PhotoFrame />
    </section>
  );
}
