import type { IconType } from "react-icons";
import { SiHtml5, SiCss3, SiJavascript, SiTailwindcss, SiReact, SiGithub } from "react-icons/si";
import CodeWindow from "./CodeWindow";
import SectionHead from "./SectionHead";
import SkillBars from "./SkillBars";
import Reveal from "./Reveal";

const cards: { title: string; text: string; Icon: IconType; color: string }[] = [
  { title: "HTML5", text: "Semantic and accessible markup.", Icon: SiHtml5, color: "text-orange-500" },
  { title: "CSS3", text: "Responsive layouts and animations.", Icon: SiCss3, color: "text-blue-500" },
  { title: "JavaScript", text: "Interactive and dynamic applications.", Icon: SiJavascript, color: "text-yellow-400" },
  { title: "Tailwind CSS", text: "Utility-first responsive design.", Icon: SiTailwindcss, color: "text-cyan-400" },
  { title: "React", text: "Building reusable UI components.", Icon: SiReact, color: "text-sky-400" },
  { title: "Git & GitHub", text: "Version control and collaboration.", Icon: SiGithub, color: "text-white" },
];

export default function Skills() {
  return (
    <section id="skills" className="mx-auto max-w-5xl overflow-x-clip px-5 py-16">
      <SectionHead file="skills.css" title="Skills & Technologies" sub="Technologies I use to build responsive and modern web applications." />
      <div className="grid gap-8 md:grid-cols-2">
        <Reveal>
          <CodeWindow file="Explorer">
            <p className="mb-5 font-bold text-blue-400">Web dev</p>
            <SkillBars />
          </CodeWindow>
        </Reveal>
        <div className="grid grid-cols-2 gap-4">
          {cards.map(({ title, text, Icon, color }, i) => (
            <Reveal key={title} from={i % 2 ? "right" : "left"}>
              <div className="h-full rounded-xl border border-line bg-card p-5">
                <Icon className={`text-5xl ${color}`} aria-hidden />
                <h3 className="mt-4 font-semibold text-white">{title}</h3>
                <p className="mt-1 text-sm text-zinc-400">{text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
