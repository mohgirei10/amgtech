"use client";
import { useEffect, useState } from "react";

export default function Loader() {
  const [phase, setPhase] = useState<"show" | "fade" | "gone">("show");
  useEffect(() => {
    const a = setTimeout(() => setPhase("fade"), 1800);
    const b = setTimeout(() => setPhase("gone"), 2400);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []);
  if (phase === "gone") return null;
  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center bg-black transition-opacity duration-500 ${phase === "fade" ? "opacity-0" : "opacity-100"}`}>
      <div className="relative flex size-56 items-center justify-center rounded-full border border-blue-950">
        <div className="spin absolute -inset-px rounded-full border-2 border-transparent border-r-blue-500 border-t-blue-500/40" />
        <div className="text-center">
          <p className="text-3xl text-zinc-400">Muhammed</p>
          <p className="mt-2 text-sm tracking-wide text-zinc-500">Web Developer</p>
        </div>
      </div>
    </div>
  );
}
