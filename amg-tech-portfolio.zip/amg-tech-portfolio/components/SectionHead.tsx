export default function SectionHead({ file, title, sub }: { file: string; title: string; sub?: string }) {
  return (
    <div className="mb-8">
      <p className="font-mono text-sm text-green-500">{`// ${file}`}</p>
      <h2 className="mt-2 text-3xl font-bold text-white">{title}</h2>
      {sub && <p className="mt-3 max-w-prose text-zinc-400">{sub}</p>}
    </div>
  );
}
