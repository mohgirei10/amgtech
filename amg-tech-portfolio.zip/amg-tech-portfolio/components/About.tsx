import CodeWindow from "./CodeWindow";
import CodeObj from "./CodeObj";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { about, aboutCards } from "@/lib/data";

export default function About() {
  return (
    <section id="about" className="mx-auto max-w-5xl overflow-x-clip px-5 py-16">
      <SectionHead file="about.js" title="About Me" />
      <div className="grid gap-8 md:grid-cols-2">
        <Reveal>
          <CodeWindow file="about.js"><CodeObj name="aboutMe" data={about} /></CodeWindow>
        </Reveal>
        <div className="space-y-4">
          {aboutCards.map((c, i) => (
            <Reveal key={c.title} from={c.from} delay={i * 80}>
              <div className="rounded-xl border border-line bg-card p-5">
                <h3 className={`text-lg font-semibold ${c.color}`}>{c.title}</h3>
                <p className="mt-2 text-zinc-400">{c.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
