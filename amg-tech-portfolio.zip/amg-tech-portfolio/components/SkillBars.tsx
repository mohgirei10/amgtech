"use client";
import { useInView } from "./Reveal";

const bars = [
  ["Javascript", 95, "bg-orange-500"], ["React", 92, "bg-blue-500"], ["Next.js", 88, "bg-yellow-500"],
  ["Tailwind CSS", 94, "bg-cyan-400"], ["Git", 80, "bg-sky-500"],
] as const;

export default function SkillBars() {
  const [ref, seen] = useInView<HTMLDivElement>();
  return (
    <div ref={ref} className="space-y-5 font-mono">
      {bars.map(([n, p, c]) => (
        <div key={n}>
          <div className="flex justify-between text-sm text-zinc-400"><span>{n}</span><span>{p}%</span></div>
          <div className="mt-2 h-2 rounded-full bg-slate-700/50">
            <div className={`h-full rounded-full ${c} transition-[width] duration-1000 ease-out`} style={{ width: seen ? `${p}%` : "0%" }} />
          </div>
        </div>
      ))}
    </div>
  );
}
