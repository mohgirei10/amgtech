"use client";
import { useState } from "react";
import { FaEnvelope, FaMapMarkerAlt, FaPhoneAlt, FaGithub, FaInstagram, FaWhatsapp } from "react-icons/fa";
import CodeWindow from "./CodeWindow";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { contact } from "@/lib/data";

const field = "mt-1 w-full border-b border-line bg-transparent py-2 text-zinc-200 outline-none placeholder:text-zinc-500 focus:border-blue-500";
const tile = "flex size-12 items-center justify-center rounded-xl bg-card text-xl";

export default function Contact() {
  const [f, setF] = useState({ name: "", email: "", message: "" });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const send = (e: React.FormEvent) => {
    e.preventDefault();
    const body = `${f.message}\n\nFrom: ${f.name} (${f.email})`;
    window.location.href = `mailto:${contact.email}?subject=${encodeURIComponent(`Portfolio message from ${f.name}`)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <section id="contact" className="mx-auto max-w-5xl overflow-x-clip px-5 py-16">
      <SectionHead file="contact.json" title="Contact Me" sub="Let's build something amazing together." />
      <div className="grid gap-10 md:grid-cols-2">
        <Reveal>
          <CodeWindow file="contact.json">
            <form onSubmit={send} className="space-y-5">
              <label className="block text-tok-key">&quot;name&quot;:<input required value={f.name} onChange={set("name")} placeholder="Your name" className={field} /></label>
              <label className="block text-tok-key">&quot;email&quot;:<input required type="email" value={f.email} onChange={set("email")} placeholder="example@email.com" className={`${field}`} /></label>
              <label className="block text-tok-key">&quot;message&quot;:<textarea required rows={5} value={f.message} onChange={set("message")} placeholder="Write your message..." className="mt-2 w-full rounded border border-line bg-transparent p-3 text-zinc-200 outline-none placeholder:text-zinc-500 focus:border-blue-500" /></label>
              <button className="rounded bg-[#0a66c2] px-6 py-2.5 text-white hover:opacity-90">Send Message</button>
            </form>
          </CodeWindow>
        </Reveal>
        <Reveal from="right">
          <h3 className="text-2xl font-bold text-white">Get In Touch</h3>
          <p className="mt-3 text-zinc-400">Whether you have a project idea, internship opportunity, freelance work, or simply want to connect, I&apos;d love to hear from you.</p>
          <ul className="mt-6 space-y-4">
            <li className="flex items-center gap-4"><span className={`${tile} text-blue-500`}><FaEnvelope aria-hidden /></span><div><p className="font-semibold text-white">Email</p><a href={`mailto:${contact.email}`} className="text-zinc-400">{contact.email}</a></div></li>
            <li className="flex items-center gap-4"><span className={`${tile} text-red-500`}><FaMapMarkerAlt aria-hidden /></span><div><p className="font-semibold text-white">Location</p><p className="text-zinc-400">{contact.location}</p></div></li>
            <li className="flex items-center gap-4"><span className={`${tile} text-green-500`}><FaPhoneAlt aria-hidden /></span><div><p className="font-semibold text-white">Phone</p><a href={`tel:${contact.phone}`} className="text-zinc-400">{contact.phoneLabel}</a></div></li>
          </ul>
          <div className="mt-6 flex gap-3 text-xl text-zinc-200">
            {[[contact.github, "GitHub", FaGithub], [contact.instagram, "Instagram", FaInstagram], [contact.whatsapp, "WhatsApp", FaWhatsapp]].map(([href, label, Icon]) => {
              const I = Icon as typeof FaGithub;
              return <a key={label as string} href={href as string} target="_blank" rel="noreferrer" aria-label={label as string} className="flex size-12 items-center justify-center rounded-xl bg-slate-700/40 hover:bg-slate-700"><I /></a>;
            })}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
