"use client";
import { useEffect, useRef, useState } from "react";

export function useInView<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setSeen(true); io.disconnect(); }
    }, { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return [ref, seen] as const;
}

export default function Reveal({ children, from = "up", delay = 0, className = "" }: { children: React.ReactNode; from?: "up" | "left" | "right"; delay?: number; className?: string }) {
  const [ref, seen] = useInView<HTMLDivElement>();
  return (
    <div ref={ref} data-from={from} style={{ transitionDelay: `${delay}ms` }} className={`reveal ${seen ? "in" : ""} ${className}`}>
      {children}
    </div>
  );
}
