import Image from "next/image";
import { FaCode } from "react-icons/fa";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";
import { projects, contact } from "@/lib/data";

const tags = ["bg-orange-500/15 text-orange-400", "bg-blue-500/15 text-blue-400", "bg-yellow-500/15 text-yellow-400", "bg-teal-500/15 text-teal-400"];

export default function Projects() {
  return (
    <section id="projects" className="mx-auto max-w-5xl overflow-x-clip px-5 py-16">
      <SectionHead file="projects.jsx" title="Featured Projects" sub="Some projects I've built with modern frontend technologies." />
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((p, i) => (
          <Reveal key={p.title} delay={i * 100}>
            <article className="h-full overflow-hidden rounded-xl border border-line bg-card">
              <div className="flex items-center justify-between bg-bar px-4 py-2.5 font-mono text-xs">
                <span className="flex items-center gap-2 text-zinc-400"><FaCode className="text-blue-400" aria-hidden />{p.file}</span>
                <span className="text-green-400">● FEATURED</span>
              </div>
              {p.image ? (
                <Image src={p.image} alt={p.title} width={600} height={360} className="h-44 w-full object-cover" />
              ) : (
                <div className="flex h-44 items-center justify-center bg-gradient-to-br from-blue-950 to-slate-900 font-mono text-2xl text-blue-300/70">{p.title}</div>
              )}
              <div className="p-5">
                <h3 className="text-xl font-semibold text-blue-200">{p.title}</h3>
                <p className="mt-3 text-zinc-400">{p.text}</p>
                <ul className="mt-4 flex flex-wrap gap-2 text-xs">
                  {p.tech.map((t, j) => <li key={t} className={`rounded-full px-3 py-1 ${tags[j % tags.length]}`}>{t}</li>)}
                </ul>
                <div className="mt-5 flex gap-3">
                  <a href={p.demo} className="rounded bg-[#0a66c2] px-5 py-2 text-white hover:opacity-90">Live Demo</a>
                  <a href={contact.github} target="_blank" rel="noreferrer" className="rounded border border-blue-900 px-5 py-2 text-white hover:bg-blue-950">GitHub</a>
                </div>
              </div>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
