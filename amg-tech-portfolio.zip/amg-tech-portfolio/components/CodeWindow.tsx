export default function CodeWindow({ file, children, className = "" }: { file: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`overflow-hidden rounded-xl border border-line bg-card shadow-2xl shadow-black/40 ${className}`}>
      <div className="flex items-center gap-2 bg-bar px-4 py-3">
        <span className="size-3 rounded-full bg-red-500" />
        <span className="size-3 rounded-full bg-yellow-500" />
        <span className="size-3 rounded-full bg-green-500" />
        <span className="ml-3 font-mono text-xs text-zinc-400">{file}</span>
      </div>
      <div className="p-5 font-mono text-sm leading-7">{children}</div>
    </div>
  );
}
