"use client";
import { useState } from "react";
import { chips } from "@/lib/data";

export default function PhotoFrame() {
  const [failed, setFailed] = useState(false);
  return (
    <div className="relative mx-auto my-24 size-64">
      <div className="orbit absolute inset-0">
        {chips.map((c, i) => (
          <span key={c} className="absolute left-1/2 top-1/2 size-0" style={{ transform: `rotate(${(360 / chips.length) * i}deg) translateY(-165px)` }}>
            <span className="absolute -translate-x-1/2 -translate-y-1/2 whitespace-nowrap rounded-lg border border-line bg-card/90 px-3 py-1.5 text-xs text-zinc-300">{c}</span>
          </span>
        ))}
      </div>
      {failed ? (
        <div className="flex size-64 items-center justify-center rounded-xl border border-line bg-card font-mono text-5xl text-blue-400">AMG</div>
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img src="/images/profile.jpg" alt="Muhammed Adamu Girei" onError={() => setFailed(true)} className="size-64 rounded-xl border border-line object-cover" />
      )}
    </div>
  );
}
